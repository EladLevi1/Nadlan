﻿Go
use Nadlan;


--חשב את רווחי החברה מכל התיווכים שנעשו השנה לפי סוג הבית. רווח מחושב ע"י ההפרש
--בין מחיר המכירה של החברה ללקוח לבין המחיר אותו ביקש הלקוח שמוכר את ביתו. יש
--להציג לכל סוג בית (לדוגמא: דירה בבנין, פנטהאוז וכדומה) את סה"כ הרווחים השנה.
select H.TypeID, year(S.SaleDate) as 'Year', sum(H.WantedPrice-S.FinalPrice) as 'Profit'
from Sales S inner join Houses H on H.SaleID = S.SaleID
where year(S.SaleDate) = '2023'
group by H.TypeID, year(S.SaleDate);



--הצג לקוחות אשר מכרו באמצעות שירותי החברה וקנו בית אחר במחיר הגבוה ממחיר המכירה.
with temp as
	(select H.OwnerID, min(S.FinalPrice) as SoldHouseMinPrice
	from Houses H inner join Sales S on H.HouseID = S.HouseID
	group by H.OwnerID)
select C.CustomerFirstName, C.CustomerLastName, max(S.FinalPrice) as SoldHouseMaxPrice, T.SoldHouseMinPrice
from Sales S inner join Houses H on H.SaleID = S.SaleID
inner join Customers C on C.CustomerID = S.BuyerID
inner join temp T on T.OwnerID = C.CustomerID
group by C.CustomerFirstName, C.CustomerLastName, T.SoldHouseMinPrice
having max(S.FinalPrice) > T.SoldHouseMinPrice;



--מהי השכונה היוקרתית ביותר? הצגו את שם השכונה ושם העיר אשר ממוצע מחירי הבתים
--שנמכרו בה הכי יקרים.
select top 1 C.CityName, N.NeighborhoodName, avg(S.FinalPrice) as AverageSales
from City C inner join Neighborhood N on N.CityID = C.CityID
inner join Houses H on H.NeighborhoodID = N.NeighborhoodID
inner join Sales S on H.SaleID = S.SaleID
group by C.CityName, N.NeighborhoodName
order by AverageSales desc;



--הצג את העובד המצטיין לכל שנה. עובד מצטיין הינו עובד שסך הרווחים ממכירותיו הכי
--גבוהה באותה שנה.
with temp as(
	select E.EmployeeID, E.EmployeeFirstName, E.EmployeeLastName, year(S.SaleDate) as Year, sum(H.WantedPrice - S.FinalPrice) as ProfitFromSales
	from Employees E inner join SalesMan SM on SM.SalesManID = E.EmployeeID
	inner join Sales S on S.SalesManID = SM.SalesManID
	inner join Houses H on H.HouseID = S.HouseID
	group by E.EmployeeID, E.EmployeeFirstName, E.EmployeeLastName, year(S.SaleDate))
select temp.*
from temp
where ProfitFromSales =
	(select max(ProfitFromSales)
	from temp t2
	where t2.Year = temp.Year)
order by Year;



--הציעו בית חדש ומרווח יותר ללקוח שרכש בית באמצעות שירותי החברה לפני שנתיים או
--יותר באותה עיר שבה גר. מרווח יותר משמעו מספר חדרים גדול יותר או שטח גדול יותר
--שימו לב כי הבית המוצע חייב להיות בית למכירה ברגע זה ואינו בית שכבר נמכר.

--(שיניתי את זה לשנה האחרונה במקום שנתיים אחורה שיהיה יותר נתונים)
with temp as
	(select S.BuyerID, C.CustomerFirstName, C.CustomerLastName, H.HouseID, H.IsSold, H.TypeID, H.Rooms, H.SquareMeter, N.NeighborhoodName, CI.CityName
	from Customers C inner join Sales S on C.CustomerID = S.BuyerID
	inner join Houses H on S.HouseID = H.HouseID
	inner join HouseType HT on HT.TypeID = H.TypeID
	inner join Neighborhood N on N.NeighborhoodID = H.NeighborhoodID
	inner join City Ci on Ci.CityID = N.CityID
	where S.SaleDate <= dateadd(year, -1, getdate()))
select Cust.CustomerFirstName, Cust.CustomerLastName, H.*, N.NeighborhoodName, C.CityName
from Houses H inner join Neighborhood N on H.NeighborhoodID = N.NeighborhoodID
inner join City C on C.CityID = N.CityID
inner join temp T on T.CityName = C.CityName
inner join Customers Cust on Cust.CustomerID = T.BuyerID
where H.IsSold = 0 and (H.Rooms > T.Rooms or H.SquareMeter > T.SquareMeter)
order by N.NeighborhoodID;