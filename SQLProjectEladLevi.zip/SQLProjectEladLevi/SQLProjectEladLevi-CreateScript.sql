Create Database Nadlan;

GO
use Nadlan;

GO
create table City(
CityID int check(CityID > 0 and CityID < 1000000) primary key not null,
CityName nvarchar(30) not null);

create table Neighborhood(
NeighborhoodID int check(NeighborhoodID > 0 and NeighborhoodID < 1000000) primary key not null,
NeighborhoodName nvarchar(30) not null,
CityID int references City(CityID) not null);

create table HouseType(
TypeID int check(TypeID > 0 and TypeID < 6) primary key not null,
TypeName nvarchar(30) not null);

create table Customers(
CustomerID int identity(1,1) primary key not null,
CustomerFirstName nvarchar(30) not null,
CustomerLastName nvarchar(30) not null,
CustomerAge int check(CustomerAge > 18 and CustomerAge < 120) not null);

create table Employees(
EmployeeID int identity(1,1) primary key not null,
EmployeeFirstName nvarchar(30) not null,
EmployeeLastName nvarchar(30) not null,
EmployeeAge int check(EmployeeAge between 18 and 120) not null,
EmployeeBirthDate date check(datediff(year, EmployeeBirthDate, getdate()) < 120) not null,
EmployeeHireDate date check(EmployeeHireDate > '2021-01-10' and EmployeeHireDate <= getdate()) not null);

create table SalesMan(
SalesManID int references Employees(EmployeeID) primary key not null);

create table SalesManSpecialize(
SalesManID int,
HouseTypeID int,
primary key (SalesManID, HouseTypeID),
foreign key (SalesManID) references SalesMan(SalesManID),
foreign key (HouseTypeID) references HouseType(TypeID));

create table Houses(
HouseID int identity(1,1) primary key not null,
OwnerID int references Customers(CustomerID) not null,
WantedPrice int check(WantedPrice between 100000 and 100000000) not null,
Rooms int check(Rooms between 1 and 20) not null,
SquareMeter int check(SquareMeter between 10 and 2000) not null,
TypeID int references HouseType(TypeID) not null,
NeighborhoodID int references Neighborhood(NeighborhoodID) not null,
IsSold bit check(IsSold in(0,1)) not null default 0);

create table Sales(
SaleID int identity(1,1) primary key not null,
HouseID int references Houses(HouseID) not null,
BuyerID int references Customers(CustomerID) not null,
SalesManID int references SalesMan(SalesManID) not null,
SaleDate date check(SaleDate > '2021-01-10' and SaleDate <= getdate()) not null,
FinalPrice int check(FinalPrice between 100000 and 100000000) not null);

alter table Houses
add SaleID int references Sales(SaleID) null;

--drop database Nadlan
--drop table City
--drop table Houses
--drop table Sales
--drop table SalesMan
--drop table Employees
--drop table Customers
--drop table Neighborhood
--drop table SalesManSpecialize
--drop table HouseType