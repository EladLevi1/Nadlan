GO
use Nadlan;

GO
insert into City(CityID, CityName)
values
(12767, 'Jerusalem'),
(34587, 'Tel Aviv'),
(12337, 'Haifa'),
(48230, 'Holon'),
(78613, 'Herzliya');

insert into Neighborhood(NeighborhoodID, NeighborhoodName, CityID) 
values
-- Jerusalem neighborhoods
(101, 'Nachlaot', 12767),
(102, 'Katamon', 12767),
(103, 'Rehavia', 12767),

-- Tel Aviv neighborhoods
(201, 'Rothschild', 34587),
(202, 'Neve Tzedek', 34587),
(203, 'Florentine', 34587),

-- Haifa neighborhoods
(301, 'Wadi Nisnas', 12337),
(302, 'German Colony', 12337),
(303, 'Hadar', 12337),

-- Holon neighborhoods
(401, 'City Center', 48230),
(402, 'Old City', 48230),
(403, 'Neve Ganim', 48230),

-- Herzliya neighborhoods
(501, 'City Center', 78613),
(502, 'Nof Yam', 78613),
(503, 'Marina', 78613);

insert into HouseType (TypeID, TypeName)
values
(1, 'Apartment'),
(2, 'Villa'),
(3, 'Penthouse'),
(4, 'Duplex'),
(5, 'Cottage');

insert into Customers (CustomerFirstName, CustomerLastName, CustomerAge) 
values
('Yoni', 'Friedman', 32),
('Yossi', 'Carmi', 41),
('Yaniv', 'Weinberg', 24),
('Eli', 'Gross', 36),
('Rachel', 'Levi', 28),
('David', 'Cohen', 49),
('Avi', 'Katz', 31),
('Shira', 'Stern', 27),
('Tal', 'Ben-David', 35),
('Maya', 'Golan', 22),
('Yair', 'Levy', 43),
('Hila', 'Cohen', 29),
('Itay', 'Green', 37),
('Rina', 'Shapira', 26),
('Nir', 'Cohen', 44);

insert into Employees (EmployeeFirstName, EmployeeLastName, EmployeeAge, EmployeeBirthDate, EmployeeHireDate)
values
('Eitan', 'Shamir', 35, '1987-09-18', '2021-08-12'),
('Avi', 'Ben-David', 29, '1993-11-30', '2021-09-01'),
('Itai', 'Grossman', 31, '1990-10-06', '2022-04-22'),
('Shimon', 'Mizrachi', 45, '1978-12-10', '2022-06-15'),
('Uri', 'Barak', 39, '1983-04-23', '2023-02-14');

insert into SalesMan (SalesManID)
values
(1),
(3),
(5);

insert into SalesManSpecialize
values
(1, 1),
(1, 4),
(1, 5),
(3, 2),
(3, 3),
(3, 1),
(5, 2),
(5, 4),
(5, 5);

insert into Houses(OwnerID, WantedPrice, Rooms, SquareMeter, TypeID, NeighborhoodID, IsSold) 
values
(1, 5000000, 5, 140, 4, 101, 1),
(2, 15000000, 10, 400, 2, 102, 0),
(3, 800000, 2, 40, 1, 103, 0),
(4, 1200000, 3, 80, 1, 201, 1),
(5, 2500000, 4, 110, 1, 202, 1),
(6, 6000000, 6, 150, 3, 203, 0),
(7, 900000, 2, 50, 1, 301, 1),
(8, 4000000, 4, 120, 5, 302, 0),
(9, 35000000, 15, 1500, 2, 303, 1),
(10, 7000000, 5, 300, 5, 401, 0),
(11, 3000000, 4, 125, 4, 402, 1),
(12, 450000, 2, 30, 1, 403, 0),
(13, 9500000, 6, 300, 2, 501, 0),
(14, 1500000, 3, 70, 1, 502, 1),
(15, 3000000, 5, 400, 5, 503, 1),
(15, 1800000, 3, 75, 1, 101, 0),
(14, 6500000, 7, 200, 4, 102, 1),
(13, 1100000, 2, 50, 1, 103, 1),
(12, 4200000, 4, 120, 1, 201, 0),
(11, 3200000, 3, 100, 1, 202, 1),
(10, 4800000, 5, 140, 3, 203, 0),
(9, 720000, 2, 45, 1, 301, 1),
(8, 3500000, 3, 110, 5, 302, 1),
(7, 28000000, 12, 1000, 2, 303, 0),
(6, 10000000, 6, 350, 2, 401, 0),
(5, 2800000, 4, 105, 4, 402, 1),
(4, 600000, 2, 30, 1, 403, 0),
(3, 8000000, 5, 250, 2, 501, 0),
(2, 1400000, 3, 70, 1, 502, 1),
(1, 2200000, 4, 200, 5, 503, 1),
(10, 3700000, 3, 110, 1, 101, 0),
(9, 9200000, 8, 350, 4, 102, 1),
(8, 1500000, 2, 55, 1, 103, 0),
(7, 5800000, 5, 150, 1, 201, 1),
(6, 3500000, 3, 95, 1, 202, 0),
(1, 5500000, 4, 130, 3, 203, 1),
(2, 690000, 2, 40, 1, 301, 1),
(3, 3200000, 3, 100, 5, 302, 0),
(4, 25000000, 10, 800, 2, 303, 1),
(5, 8000000, 7, 300, 2, 401, 0),
(15, 15000000, 8, 350, 3, 402, 1),
(14, 800000, 3, 70, 1, 403, 0),
(13, 4200000, 5, 260, 5, 501, 1),
(12, 4600000, 4, 320, 4, 502, 1),
(11, 10000000, 8, 400, 2, 503, 0),
(2, 20000000, 12, 800, 2, 102, 0);

insert into Sales(HouseID, BuyerID, SalesManID, SaleDate, FinalPrice)
values
(1, 4, 5, '2021-02-11', 4700000),
(4, 14, 1, '2021-05-17', 1100000),
(5, 8, 3, '2021-05-28', 2300000),
(7, 2, 1, '2021-06-15', 850000),
(9, 11, 5, '2021-07-28', 30000000),
(11, 12, 1, '2021-09-11', 2400000),
(14, 15, 3, '2021-10-12', 1480000),
(15, 13, 5, '2021-11-21', 2750000),
(17, 3, 1, '2022-01-01', 4700000),
(18, 7, 3, '2022-02-18', 1100000),
(20, 1, 1, '2022-03-12', 2400000),
(22, 8, 3, '2022-04-08', 680000),
(23, 2, 5, '2022-05-04', 3200000),
(26, 9, 1, '2022-07-21', 2400000),
(29, 1, 3, '2022-09-27', 1300000),
(30, 13, 5, '2022-12-12', 2000000),
(32, 7, 1, '2023-01-04', 8700000),
(34, 6, 3, '2023-01-18', 5300000),
(36, 3, 3, '2023-01-29', 5000000),
(37, 11, 1, '2023-02-10', 630000),
(39, 7, 5, '2023-02-17', 23000000),
(41, 14, 3, '2023-02-23', 13500000),
(43, 15, 5, '2023-03-15', 3900000),
(44, 5, 1, '2023-03-20', 4100000);

update Houses
set SaleID = 
  case HouseID
    when 1 then 1
    when 4 then 2
    when 5 then 3
    when 7 then 4
    when 9 then 5
    when 11 then 6
    when 14 then 7
    when 15 then 8
	when 17 then 9
    when 18 then 10
    when 20 then 11
    when 22 then 12
    when 23 then 13
    when 26 then 14
    when 29 then 15
    when 30 then 16
	when 32 then 17
    when 34 then 18
    when 36 then 19
    when 37 then 20
    when 39 then 21
    when 41 then 22
    when 43 then 23
    when 44 then 24
  end
where HouseID in (1, 4, 5, 7, 9, 11, 14, 15, 17, 18, 20, 22, 23, 26, 29, 30, 32, 34, 36, 37, 39, 41, 43, 44);